use chinook
-- 1.	Does any table have missing values or duplicates? If yes how would you handle it ?
Select * from album
Select * from artist
Select Count(*) from customer
where company is NULL 
Select Count(*) from customer
where state is NULL
Select Count(*) from customer
where fax is NULL  -- 49 company, 29 state, 47 fax values are null in the customer table
Select * from employee -- 1 reports_to is null in this table
Select * from genre
Select * from invoice
Select * from invoice_line
Select * from media_type
Select * from playlist
Select * from playlist_track
Select count(*) from track
where composer is NULL -- there are 978 composer values are null in this table

-- 2. Find the top-selling tracks and top artist in the USA and identify their most famous genres
-- Identify top-selling tracks,top-artists and top genres
Select t.name as track_name,ar.name as artist_name, g.name as genre_name, sum(il.quantity) as total_sales
from track t
join invoice_line il on t.track_id = il.track_id
join invoice i on i.invoice_id = il.invoice_id
join album al on al.album_id = t.album_id
join artist ar on ar.artist_id = al.artist_id
join genre g on g.genre_id = t.genre_id
where i.billing_country = 'USA'
group by t.name,ar.name,g.name
order by total_sales desc
Limit 10;

-- 3. What is the customer demographic breakdown (age, gender, location) of Chinook's customer base?
-- customer count on the basis of location
Select country,count(*) as customer_count
from customer
group by country
order by  customer_count desc
    
-- 4. Calculate the total revenue and number of invoices for each country, state, and city
Select billing_country as country, billing_state as state, billing_city as city, count(invoice_id) as number_of_invoices, sum(total) as total_revenue
from invoice
group by billing_country,billing_state,billing_city
order by total_revenue desc;

-- 5. Find the top 5 customers by total revenue in each country
with ranked_country as (Select c.country, concat(c.first_name," ",c.last_name)as customer_name, sum(i.total) as total_revenue,
dense_rank() over(partition by c.country order by sum(i.total) desc) as country_rank
from customer c
join invoice i on c.customer_id = i.customer_id
group by c.country,concat(c.first_name," ",c.last_name)
order by c.country asc)

Select country,customer_name,total_revenue
from ranked_country
where country_rank <=5

-- 6. Identify the top-selling track for each customer
Select concat(c.first_name, " " , c.last_name) as customer_name,
t.name as track_name, SUM(il.quantity) as total_sales
from customer c
left join invoice i on i.customer_id = c.customer_id
left join invoice_line il on il.invoice_id = i.invoice_id
left join track t on t.track_id = il.track_id
group by customer_name, track_name
order by total_sales desc;
    
-- 7. Are there any patterns or trends in customer purchasing behavior (e.g., frequency of purchases, preferred payment methods, average order value)?
Select customer_id, count(invoice_id) as purchase_frequency, avg(total) as avg_order_value
from invoice
group by customer_id
order by avg(total) desc

-- 8. What is the customer churn rate?
-- churn rate for 2017
with first_three_months as (select count(customer_id) as customer_count 
from invoice
where invoice_date between '2017-01-01' and '2017-03-31'),

last_three_months as(select count(customer_id) as customer_count 
from invoice
where invoice_date between '2017-10-01' and '2017-12-31') 
select ((first3.customer_count)-(last3.customer_count))/(first3.customer_count) * 100 as churn_rate_2017
from first_three_months as first3,last_three_months as last3;

-- churn rate for 2018
with first_three_months as (select count(customer_id) as customer_count 
from invoice
where invoice_date between '2018-01-01' and '2018-03-31'),

last_three_months as(select count(customer_id) as customer_count 
from invoice
where invoice_date between '2018-10-01' and '2018-12-31') 
select ((first3.customer_count)-(last3.customer_count))/(first3.customer_count) * 100 as churn_rate_2018
from first_three_months as first3,last_three_months as last3;

-- churn rate for 2019
with first_three_months as (select count(customer_id) as customer_count 
from invoice
where invoice_date between '2019-01-01' and '2019-03-31'),

last_three_months as(select count(customer_id) as customer_count 
from invoice
where invoice_date between '2019-10-01' and '2019-12-31') 
select ((first3.customer_count)-(last3.customer_count))/(first3.customer_count) * 100 as churn_rate_2019
from first_three_months as first3,last_three_months as last3;

-- churn rate for 2020
with first_three_months as(select count(customer_id) as customer_count 
from invoice
where invoice_date between '2020-01-01' and '2020-03-31'),

last_three_months as(select count(customer_id) as customer_count 
from invoice
where invoice_date between '2020-10-01' and '2020-12-31') 
select ((first3.customer_count)-(last3.customer_count))/(first3.customer_count) * 100 as churn_rate_2020
from first_three_months as first3,last_three_months as last3;

-- 9. Calculate the percentage of total sales contributed by each genre in the USA and identify the best-selling genres and artists.
with total_revenue as(Select sum(total) as total_sales_USA
from invoice
where billing_country = 'USA'),
genre_sales as(Select g.genre_id, g.name, sum(t.unit_price * il.quantity) as total_sales_genre 
from track t
left join genre g on g.genre_id = t.genre_id
left join invoice_line il on il.track_id = t.track_id
left join invoice i on i.invoice_id = il.invoice_id
where billing_country = 'USA'
group by g.genre_id,g.name
order by total_sales_genre desc),

percentage as(Select genre_id, name, ROUND(total_sales_genre/(Select total_sales_USA from total_revenue) * 100,2) as percentage_contribution
from genre_sales)
Select p.genre_id, p.name as genre_name, ar.name as artist_name,p.percentage_contribution
from percentage p
left join track t on t.genre_id = p.genre_id
left join album al on al.album_id = t.album_id
left join artist ar on ar.artist_id = al.artist_id
group by p.genre_id, p.name, ar.name, p.percentage_contribution

-- 10. Find customers who have purchased tracks from at least 3 different+ genres.
Select c.customer_id, concat(c.first_name," ",c.last_name) as customer_name, count(DISTINCT g.name) as genre_count
from customer c
left join invoice i on c.customer_id = i.customer_id
left join invoice_line il on i.invoice_id = il.invoice_id
left join track t on il.track_id = t.track_id
left join genre g on t.genre_id = g.genre_id
group by c.customer_id
having count(DISTINCT g.name) >= 3
order by genre_count desc;

-- 11. Rank genres based on their sales performance in the USA.
with genre_sales as (Select g.name as genre_name, sum(il.unit_price * il.quantity) as total_sales
from genre g
join track t on g.genre_id = t.genre_id
join invoice_line il on t.track_id = il.track_id
join invoice i on il.invoice_id = i.invoice_id
join customer c on i.customer_id = c.customer_id
where c.country = 'USA'
group by g.genre_id, g.name
order by total_sales desc)

Select genre_name,total_sales,
dense_rank() over (order by total_sales desc) as sales_rank
from genre_sales

-- 12. Identify customers who have not made a purchase in the last 3 months.
Select c.customer_id, concat(c.first_name, " " , c.last_name) as customer_name, max(i.invoice_date) as last_purchase_date
from customer c
join invoice i on c.customer_id = i.customer_id
group by c.customer_id
having last_purchase_date < DATE_SUB((Select max(invoice_date) from invoice), interval 3 month);

-- Subjective Questions - 
-- 1. Recommend the three albums from the new record label that should be prioritised for advertising and promotion in the USA based on genre sales analysis.
-- Identify the top-selling genre
with genre_sales as(Select g.genre_id, g.name as genre_name, sum(il.unit_price * il.quantity) as total_genre_sales
from genre g
join track t on g.genre_id = t.genre_id
join album al on t.album_id = al.album_id
join invoice_line il on t.track_id = il.track_id
join invoice i on il.invoice_id = i.invoice_id
join customer c on i.customer_id = c.customer_id
where c.country = 'USA' 
group by g.genre_id, g.name
order by total_genre_sales desc
Limit 1),
-- Identify the top 3 albums wrt top genre
top_album as(Select al.album_id, al.title as album_name, g.name as genre_name, sum(il.unit_price * il.quantity) as total_album_sales
from album al
join track t on al.album_id = t.album_id
join genre g on t.genre_id = g.genre_id
join invoice_line il on t.track_id = il.track_id
join invoice i on il.invoice_id = i.invoice_id
join customer c on i.customer_id = c.customer_id
where c.country = 'USA'
and g.genre_id = (Select genre_id from genre_sales) -- Match the top genre
group by al.album_id, al.title, g.name
order by total_album_sales desc
Limit 3)
Select album_name, genre_name, total_album_sales
from top_album;

-- 2. Determine the top-selling genres in countries other than the USA and identify any commonalities or differences.
Select g.genre_id,g.name as genre_name, sum(il.unit_price * il.quantity) as total_sales
from genre g
join track t on g.genre_id = t.genre_id
join invoice_line il on t.track_id = il.track_id
join invoice i on il.invoice_id = i.invoice_id
where billing_country != 'USA'
group by g.genre_id, g.name
order by total_sales desc;

-- 3. Customer Purchasing Behavior Analysis: How do the purchasing habits (frequency, basket size, spending amount) of long-term customers differ 
-- from those of new customers? What insights can these patterns provide about customer loyalty and retention strategies?
with month_difference as(Select i.customer_id, max(invoice_date), min(invoice_date), 
ABS(TIMESTAMPDIFF(MONTH, max(invoice_date), min(invoice_date))) time_for_each_customer, 
sum(total) sales, sum(quantity) items, count(invoice_date) frequency 
from invoice i
left join customer c on c.customer_id = i.customer_id
left join invoice_line il on il.invoice_id = i.invoice_id
group by i.customer_id
order by time_for_each_customer desc),
average_time as(Select avg(time_for_each_customer) as average from month_difference),
customer_category as(Select *,
Case
when time_for_each_customer > (Select average from average_time) then "Long-term Customer"
else "New Customer" 
end as category
from month_difference)
Select category, sum(sales) total_spending, sum(items) basket_size, count(frequency) frequency_count 
from customer_category
group by category

-- 4. Product Affinity Analysis: Which music genres, artists, or albums are frequently purchased together by customers? How can this information guide product recommendations and cross-selling initiatives?
-- Different genres
with cte as(Select invoice_id, COUNT(DISTINCT g.name) num
from invoice_line il
left join track t on t.track_id = il.track_id
left join genre g on  g.genre_id = t.genre_id
group by invoice_id
having COUNT(DISTINCT g.name) > 1)
Select cte.invoice_id, num, g.name as genre
from cte
left join invoice_line il on il.invoice_id = cte.invoice_id
left join track t on t.track_id = il.track_id
left join genre g on  g.genre_id = t.genre_id
group by cte.invoice_id, num, g.name;

-- Different albums
with cte as(Select invoice_id, COUNT(DISTINCT al.title) num 
from invoice_line il
left join track t on t.track_id = il.track_id
left join album al on al.album_id = t.album_id
group by invoice_id  
having COUNT(DISTINCT al.title) > 1)
Select cte.invoice_id, num, al.title as album
from cte
left join invoice_line il on il.invoice_id = cte.invoice_id
left join track t on t.track_id = il.track_id
left join album al on  al.album_id = t.album_id
group by cte.invoice_id, num, al.title;

-- Different artist
with cte as(Select invoice_id, COUNT(DISTINCT a.name) num 
from invoice_line il
left join track t on t.track_id = il.track_id
left join album al on al.album_id = t.album_id
left join artist a on a.artist_id = al.artist_id
group by invoice_id 
having COUNT(DISTINCT a.name) > 1)
Select cte.invoice_id, num, a.name as artist
from cte
left join invoice_line il on il.invoice_id = cte.invoice_id
left join track t on t.track_id = il.track_id
left join album al on  al.album_id = t.album_id
left join artist a on a.artist_id = al.artist_id
group by cte.invoice_id, num, a.name;


-- 5. Regional Market Analysis: Do customer purchasing behaviors and churn rates vary across different geographic regions or store locations? How might these correlate with local demographic or economic factors?
with first_three_months as(Select billing_country as country, Count(customer_id) as customer_count
from invoice
where invoice_date between '2017-01-01' and '2017-03-31'
group by billing_country),
last_three_months as (Select billing_country as country, COUNT(customer_id) customer_count 
from invoice
where invoice_date between '2020-10-01' and '2020-12-31' 
group by billing_country)

select first3.country, ((first3.customer_count)-coalesce(last3.customer_count,0))/(first3.customer_count)* 100 as churn_rate
from first_three_months as first3
left join last_three_months as last3
on first3.country = last3.country;

with first_three_months as(Select billing_city as city, Count(customer_id) as customer_count
from invoice
where invoice_date between '2017-01-01' and '2017-03-31'
group by billing_city),
last_three_months as (Select billing_city as city, COUNT(customer_id) customer_count 
from invoice
where invoice_date between '2020-10-01' and '2020-12-31' 
group by billing_city)

select first3.city, ((first3.customer_count)-coalesce(last3.customer_count,0))/(first3.customer_count)* 100 as churn_rate
from first_three_months as first3
left join last_three_months as last3
on first3.city = last3.city;

with first_three_months as(Select billing_state as state, Count(customer_id) as customer_count
from invoice
where invoice_date between '2017-01-01' and '2017-03-31'
group by billing_state),
last_three_months as (Select billing_state as state, COUNT(customer_id) customer_count 
from invoice
where invoice_date between '2020-10-01' and '2020-12-31' 
group by billing_state)

select first3.state, ((first3.customer_count)-coalesce(last3.customer_count,0))/(first3.customer_count)* 100 as churn_rate
from first_three_months as first3
left join last_three_months as last3
on first3.state = last3.state;

Select billing_country, COUNT(invoice_id) as  num_invoices, avg(total) as avg_sales
from invoice
group by billing_country
order by COUNT(invoice_id) desc,avg(total) desc

-- 6. Customer Risk Profiling: Based on customer profiles (age, gender, location, purchase history), which customer segments are more likely to churn or pose a higher risk of reduced spending? What factors contribute to this risk?
Select i.customer_id, concat(c.first_name, " ", c.last_name) as customer_name, i.billing_country,
sum(i.total) as total_spending, COUNT(i.invoice_id) as num_of_orders 
from invoice i
left join customer c on c.customer_id = i.customer_id
group by i.customer_id, concat(c.first_name, " ", c.last_name), i.billing_country
order by total_spending desc, num_of_orders desc

-- 7. Customer Lifetime Value Modeling:How can you leverage customer data (tenure, purchase history, engagement) to predict the lifetime value of different customer segments?This could inform targeted marketing and loyalty program strategies. Can you observe any common characteristics or purchase patterns among customers who have stopped purchasing?

with cte as(select inv.customer_id,inv.billing_country,inv.invoice_date, concat(c.first_name,' ',c.last_name) as customer_name,inv.total as invoice_total
from invoice inv
left join customer c on c.customer_id = inv.customer_id
group by customer_id,2,3,inv.total
order by customer_name),
cte2 as(
select customer_id, sum(total) as LTV
from invoice
group by customer_id)
select cte.customer_id, cte.billing_country, cte.invoice_date, cte.customer_name,cte.invoice_total, cte2.LTV
from cte left join cte2 on cte.customer_id = cte2.customer_id
order by cte2.LTV desc,cte.customer_name, cte.invoice_date;

-- 10. How can you alter the "Albums" table to add a new column named "ReleaseYear" of type INTEGER to store the release year of each album?
Alter table album
Add column release_year INT DEFAULT 0;
DESC album;

-- 11. Chinook is interested in understanding the purchasing behavior of customers based on their geographical location. They want to know the average total amount spent by customers from each country, along with the number of customers and 
-- the average number of tracks purchased per customer. Write an SQL query to provide this information.
with cte as (SELECT c.country,count(il.track_id) as track_count,count(DISTINCT c.customer_id) as total_customers,
sum(il.unit_price * il.quantity) as total_spent
from customer c
join invoice i on c.customer_id = i.customer_id
join invoice_line il on i.invoice_id = il.invoice_id
group by  c.country)

Select country,total_customers,total_spent,Round((total_spent/total_customers),2) as avg_total_spent_per_customer,
Round((track_count / total_customers),2) avg_tracks_per_customer
from cte
order by total_spent desc;






